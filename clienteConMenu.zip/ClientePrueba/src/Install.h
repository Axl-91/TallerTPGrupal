#ifndef _INSTALL_H_
#define _INSTALL_H_


#define INSTALLED_TEXTURE_GUNS "guns.png"
#define INSTALLED_TEXTURE_WALLS "walls.png"
#define INSTALLED_TEXTURE_HUD "hud.png"
#define INSTALLED_TEXTURE_OBJECTS "objects.png"



#endif
