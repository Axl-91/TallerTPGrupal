#ifndef _WEAPON_T_H_
#define _WEAPON_T_H_

typedef enum{
    NONE=0,
    KNIFE=1,
    GUN=2,
    MACHINE_GUN=3,
    CHAIN_CANON=4,
    ROCKET_LAUNCHER=5
}weapon_t;

#endif
