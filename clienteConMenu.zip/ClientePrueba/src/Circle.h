#ifndef _CIRCLE_H_
#define _CIRCLE_H_

typedef struct{
    float x;
    float y;
    float radius;
}circle;


#endif
