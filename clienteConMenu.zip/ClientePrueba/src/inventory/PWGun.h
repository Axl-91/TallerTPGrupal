#ifndef _PW_GUN_H_
#define _PW_GUN_H_

#include "PlayerWeapon.h"

class PWGun: public PlayerWeapon{
public:
    PWGun();
    ~PWGun();
};

#endif
