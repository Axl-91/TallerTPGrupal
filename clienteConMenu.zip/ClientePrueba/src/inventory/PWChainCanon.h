#ifndef _PW_CHAIN_CANON_H_
#define _PW_CHAIN_CANON_H_

#include "PlayerWeapon.h"

class PWChainCanon: public PlayerWeapon{
public:
    PWChainCanon();
    ~PWChainCanon();
};

#endif
