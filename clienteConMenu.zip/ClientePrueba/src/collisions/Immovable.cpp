#include "Collidable.h"
#include "Immovable.h"

Immovable::Immovable(/* args */){
}


Immovable::~Immovable(){
}
