#include "Collidable.h"
#include "Movable.h"

Movable::Movable(/* args */){}
Movable::~Movable(){}
