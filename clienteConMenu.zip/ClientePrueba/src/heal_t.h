#ifndef _HEAL_T_H_
#define _HEAL_T_H_

typedef enum{
    BLOOD = 17,
    FOOD = 3,
    MEDICAL_EQUIPMENT = 4
}heal_t;


#endif
